# Restaurant menu with follow along highlighter

A Pen created on CodePen.io. Original URL: [https://codepen.io/scharan/pen/mqjLrz](https://codepen.io/scharan/pen/mqjLrz).

A restaurant menu template built using HTML, CSS, JS.